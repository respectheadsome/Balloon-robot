#ifndef _OUTRIGHT_
#define _OUTRIGHT_
#include <stm32f4xx_hal.h>

#include "HardwareInfo.c"
#include <SetMotor.h>
#include <SetWaitForTime.h>
void outright()
{
    SetMotor(_M1_, 100);
    SetMotor(_M2_, 100);
    SetWaitForTime(0.7);
    SetMotor(_M1_, 55);
    SetMotor(_M2_, -55);
    SetWaitForTime(0.5);
    SetMotor(_M1_, 100);
    SetMotor(_M2_, 100);
    SetWaitForTime(0.2);
}
#endif

