#ifndef _JMSUB1_
#define _JMSUB1_
#include "HardwareInfo.c"

void JMSub1()
{
}
#endif

