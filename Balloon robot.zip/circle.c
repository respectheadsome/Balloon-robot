#ifndef _CIRCLE_
#define _CIRCLE_
#include <stm32f4xx_hal.h>

#include "HardwareInfo.c"
#include "catch_line.c"
#include "go_bmp.c"
#include "rurnleft.c"
#include "line_bmp.c"
void circle()
{
    catch_line(100, 1);
    go_bmp(100, 100);
    rurnleft();
    catch_line(100, 1);
    go_bmp(100, 100);
    rurnleft();
    catch_line(100, 1);
    go_bmp(100, 100);
    rurnleft();
    catch_line(100, 1);
    go_bmp(100, 100);
    rurnleft();
    line_bmp(100, 7000);
}
#endif

