#ifndef _ZHAQIQIU_
#define _ZHAQIQIU_
#include <stm32f4xx_hal.h>

#include "HardwareInfo.c"
void ZhaQiQiu()
{
}
#endif

