#include <stm32f4xx_hal.h>
u16 tempCS=0;
u16 G1,G2,G3,G4,G5;

#include "HardwareInfo.c"
#include "JMLib.c"
#include <SetMotorPower.h>
#include "LineColor.c"
#include "outright.c"
#include "catch_line.c"
#include "go_bmp.c"
#include "rurnleft.c"
#include "line_bmp.c"
#include <SetWaitForTime.h>
#include <SetAICamData.h>
#include "center.c"
#include <GetAICamData.h>
#include <SetDisplayVar.h>
#include "turn_angle.c"
#include <SetWaitForStraight.h>
// define global var
unsigned int S1 = 0;
unsigned int S2 = 0;
unsigned int S3 = 0;
unsigned int S4 = 0;
unsigned int S5 = 0;
unsigned int xuan = 0;
unsigned int g_temp = 0;
double line_proportion = 0.5;   //Ѳ�߶���
long T15 = 0;   //���15·���ж�
long light_ws = 0;   //��Բ��������˳ʱ�뽫�������ó�5����ʱ�����ó�1
int mode = 1;
int sp = 40;
int angle = 1;
unsigned int S6 = 0;
unsigned int S7 = 0;
long g_1 = 0;

int main(void)
{
    M6RCU_Init();
    long var0 = 0;
    long var1 = 0;
    long com = 0;
    int red = 0;
    int blue = 0;
    long vl = 0;
    long vr = 0;
    long var2 = 0;
    long var3 = 0;
    long var4 = 0;
    long var5 = 0;
    long vara = 0;
    long varb = 0;
    long varc = 0;
    long vard = 0;
    long vare = 0;
    long varf = 0;
    long varg = 0;
    long varh = 0;
    SetMotorPower(99, 100, 100, 100);
    LineColor(0);
    outright();
    catch_line(100, 1);
    go_bmp(100, 140);
    rurnleft();
    catch_line(100, 1);
    go_bmp(100, 140);
    rurnleft();
    catch_line(100, 1);
    go_bmp(100, 140);
    rurnleft();
    catch_line(100, 1);
    go_bmp(100, 140);
    rurnleft();
    line_bmp(100, 7600);
    SetWaitForTime(0.6);
    SetAICamData(4, 0);
    center();
    SetWaitForTime(0.3);
    line_bmp(100, 4100);
    while (1)
    {
        SetWaitForTime(0.3);
        var0 = GetAICamData(1);
        SetDisplayVar(10, var0, YELLOW, BLACK);
        if ( var0<90||var0>170 )
        {
            line_bmp(100, 300);
            SetWaitForTime(0.3);
            turn_angle(-50, 1320);
            SetWaitForTime(0.4);
            SetWaitForStraight(_M1_, _M2_, 100, 1700);
            SetWaitForStraight(_M1_, _M2_, -100, 1700);
            turn_angle(50, 1320);
            SetWaitForTime(0.3);
        }
        catch_line(100, 1);
        line_bmp(100, 7950);
        SetWaitForTime(0.3);
        var0 = GetAICamData(1);
        SetDisplayVar(10, var0, YELLOW, BLACK);
        if ( var0<100||var0>170 )
        {
            line_bmp(100, 300);
            SetWaitForTime(0.3);
            turn_angle(-50, 1300);
            SetWaitForTime(0.4);
            SetWaitForStraight(_M1_, _M2_, 100, 1900);
            SetWaitForStraight(_M1_, _M2_, -100, 1900);
            turn_angle(50, 1300);
            SetWaitForTime(0.3);
        }
        else
        {
            line_bmp(100, 300);
        }
        line_bmp(100, 3000);
        SetWaitForTime(0.3);
        var0 = GetAICamData(1);
        SetDisplayVar(10, var0, YELLOW, BLACK);
        if ( var0<100||var0>160 )
        {
            line_bmp(100, 350);
            SetWaitForTime(0.3);
            turn_angle(-50, 1300);
            SetWaitForTime(0.4);
            SetWaitForStraight(_M1_, _M2_, 100, 1100);
            SetWaitForStraight(_M1_, _M2_, -100, 1100);
            turn_angle(50, 1300);
            SetWaitForTime(0.3);
        }
        catch_line(100, 1);
        line_bmp(100, 5450);
        SetWaitForTime(0.3);
        var0 = GetAICamData(1);
        SetDisplayVar(10, var0, YELLOW, BLACK);
        if ( var0<100||var0>160 )
        {
            line_bmp(100, 650);
            SetWaitForTime(0.3);
            turn_angle(-50, 1360);
            SetWaitForTime(0.4);
            SetWaitForStraight(_M1_, _M2_, 100, 5400);
            SetWaitForStraight(_M1_, _M2_, -100, 5400);
            turn_angle(50, 1360);
            SetWaitForTime(0.3);
        }
        else
        {
            line_bmp(100, 650);
        }
        line_bmp(100, 2300);
        SetWaitForTime(0.3);
        var0 = GetAICamData(1);
        SetDisplayVar(10, var0, YELLOW, BLACK);
        if ( var0<95||var0>160 )
        {
            line_bmp(100, 200);
            SetWaitForTime(0.3);
            turn_angle(-50, 1300);
            SetWaitForTime(0.4);
            SetWaitForStraight(_M1_, _M2_, 100, 1100);
            SetWaitForStraight(_M1_, _M2_, -100, 1100);
            turn_angle(50, 1300);
            SetWaitForTime(0.3);
        }
        catch_line(100, 1);
        line_bmp(100, 6530);
        SetWaitForTime(0.3);
        var0 = GetAICamData(1);
        SetDisplayVar(10, var0, YELLOW, BLACK);
        if ( var0<120||var0>160 )
        {
            line_bmp(100, 600);
            SetWaitForTime(0.3);
            turn_angle(-50, 1330);
            SetWaitForTime(0.4);
            SetWaitForStraight(_M1_, _M2_, 100, 5000);
            SetWaitForStraight(_M1_, _M2_, -100, 5000);
            turn_angle(50, 1330);
            SetWaitForTime(0.3);
        }
        else
        {
            line_bmp(100, 600);
        }
        line_bmp(100, 2850);
        SetWaitForTime(0.3);
        var0 = GetAICamData(1);
        SetDisplayVar(10, var0, YELLOW, BLACK);
        if ( var0<100||var0>160 )
        {
            line_bmp(100, 350);
            SetWaitForTime(0.3);
            turn_angle(-50, 1320);
            SetWaitForTime(0.4);
            SetWaitForStraight(_M1_, _M2_, 100, 4200);
            SetWaitForStraight(_M1_, _M2_, -100, 4200);
            turn_angle(50, 1320);
            SetWaitForTime(0.3);
        }
        catch_line(100, 1);
        line_bmp(100, 4600);
        SetWaitForTime(0.3);
        var0 = GetAICamData(1);
        SetDisplayVar(10, var0, YELLOW, BLACK);
        if ( var0<80||var0>160 )
        {
            line_bmp(100, 400);
            SetWaitForTime(0.3);
            turn_angle(-50, 1350);
            SetWaitForTime(0.4);
            SetWaitForStraight(_M1_, _M2_, 100, 2000);
            SetWaitForStraight(_M1_, _M2_, -100, 2000);
            turn_angle(50, 1350);
            SetWaitForTime(0.3);
        }
        line_bmp(100, 3200);
        go_bmp(100, 2000);
        catch_line(100, 1);
        SetWaitForTime(0.2);
        go_bmp(-100, 1900);
    }
    while(1);
}

