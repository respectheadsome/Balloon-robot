#ifndef _CENTER_
#define _CENTER_
#include <stm32f4xx_hal.h>

#include "HardwareInfo.c"
#include <SetMotor.h>
#include <SetWaitForTime.h>
void center()
{
    SetMotor(_M1_, -55);
    SetMotor(_M2_, 55);
    SetWaitForTime(0.43);
    SetMotor(_M1_, 100);
    SetMotor(_M2_, 100);
    SetWaitForTime(0.3);
    SetMotor(_M1_, 0);
    SetMotor(_M2_, 0);
    SetWaitForTime(0.2);
    SetMotor(_M1_, -100);
    SetMotor(_M2_, -100);
    SetWaitForTime(0.35);
    SetMotor(_M1_, 55);
    SetMotor(_M2_, -55);
    SetWaitForTime(0.43);
    SetMotor(_M1_, 0);
    SetMotor(_M2_, 0);
}
#endif

