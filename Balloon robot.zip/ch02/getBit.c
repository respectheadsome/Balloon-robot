#ifndef _GETBIT_
#define _GETBIT_
#include "HardwareInfo.c"

int getBit(unsigned char ch, unsigned char bit)
{
    
      return   ch   &   (0x01   <<   (bit-1))   ?   1   :   0;   
    
}
#endif

