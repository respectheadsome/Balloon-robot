#include "HardwareInfo.c"
#include "JMLib.c"
#include "LineColor.c"
#include <SetWaitForStraight.h>
#include "turnright.c"
#include "line_bmp.c"
#include <SetWaitForTime.h>
#include <SetAICamData.h>
#include "turn_angle.c"
#include <GetAICamData.h>
#include "catch_line.c"
u16 tempCS=0;
u16 G1,G2,G3,G4,G5;

// define global var
unsigned int S1 = 0;
unsigned int S2 = 0;
unsigned int S3 = 0;
unsigned int S4 = 0;
unsigned int S5 = 0;
unsigned int xuan = 0;
unsigned int g_temp = 0;
double line_proportion = 0.5;   //Ѳ�߶���
long T15 = 0;   //���15·���ж�
long light_ws = 0;   //��Բ��������˳ʱ�뽫�������ó�5����ʱ�����ó�1
int mode = 1;
int sp = 40;
int angle = 1;
unsigned int S6 = 0;
unsigned int S7 = 0;
long g_1 = 0;

int main(void)
{
    M6RCU_Init();
    long var0 = 0;
    long var1 = 0;
    long com = 0;
    int red = 0;
    int blue = 0;
    long vl = 0;
    long vr = 0;
    long var2 = 0;
    long var3 = 0;
    LineColor(0);
    SetWaitForStraight(_M1_, _M2_, 100, 3500);
    turnright();
    line_bmp(100, 60700);
    SetWaitForTime(0.5);
    SetAICamData(4, 0);
    while (1)
    {
        turn_angle(-50, 1200);
        SetWaitForTime(0.5);
        SetWaitForStraight(_M1_, _M2_, 100, 2000);
        SetWaitForStraight(_M1_, _M2_, -100, 2000);
        turn_angle(50, 1200);
        SetWaitForTime(0.5);
        line_bmp(80, 5300);
        SetWaitForTime(0.5);
        var0 = GetAICamData(1);
        if ( var0<100||var0>160 )
        {
            turn_angle(-50, 1200);
            SetWaitForTime(0.5);
            SetWaitForStraight(_M1_, _M2_, 80, 2000);
            SetWaitForStraight(_M1_, _M2_, -80, 2000);
            turn_angle(50, 1200);
        }
        SetWaitForTime(0.5);
        catch_line(100, 1);
        line_bmp(80, 8300);
        SetWaitForTime(0.5);
        var0 = GetAICamData(1);
        if ( var0<110||var0>160 )
        {
            turn_angle(-50, 1200);
            SetWaitForTime(0.5);
            SetWaitForStraight(_M1_, _M2_, 80, 2000);
            SetWaitForStraight(_M1_, _M2_, -80, 2000);
            turn_angle(50, 1200);
            SetWaitForTime(0.5);
        }
        catch_line(100, 1);
        line_bmp(80, 3400);
        SetWaitForTime(0.5);
        var0 = GetAICamData(1);
        if ( var0<110||var0>160 )
        {
            turn_angle(-50, 1250);
            SetWaitForTime(0.5);
            SetWaitForStraight(_M1_, _M2_, 80, 2000);
            SetWaitForStraight(_M1_, _M2_, -80, 2000);
            turn_angle(50, 1250);
            SetWaitForTime(0.5);
        }
        line_bmp(80, 2800);
        SetWaitForTime(0.5);
        var0 = GetAICamData(1);
        if ( var0<110||var0>160 )
        {
            turn_angle(-50, 1200);
            SetWaitForTime(0.5);
            SetWaitForStraight(_M1_, _M2_, 80, 4000);
            SetWaitForStraight(_M1_, _M2_, -80, 4000);
            turn_angle(50, 1200);
            SetWaitForTime(0.5);
        }
        line_bmp(80, 2500);
        SetWaitForTime(0.5);
        var0 = GetAICamData(1);
        if ( var0<110||var0>160 )
        {
            turn_angle(-50, 1200);
            SetWaitForTime(0.5);
            SetWaitForStraight(_M1_, _M2_, 80, 2000);
            SetWaitForStraight(_M1_, _M2_, -80, 2000);
            turn_angle(50, 1200);
            SetWaitForTime(0.5);
        }
        catch_line(100, 1);
        line_bmp(80, 7000);
        SetWaitForTime(0.5);
        var0 = GetAICamData(1);
        if ( var0<110||var0>160 )
        {
            turn_angle(-50, 1200);
            SetWaitForTime(0.5);
            SetWaitForStraight(_M1_, _M2_, 80, 4000);
            SetWaitForStraight(_M1_, _M2_, -80, 4000);
            turn_angle(50, 1200);
            SetWaitForTime(0.5);
        }
        line_bmp(80, 4000);
        SetWaitForTime(0.5);
        var0 = GetAICamData(1);
        if ( var0<110||var0>160 )
        {
            turn_angle(-50, 1200);
            SetWaitForTime(0.5);
            SetWaitForStraight(_M1_, _M2_, 80, 4000);
            SetWaitForStraight(_M1_, _M2_, -80, 4000);
            turn_angle(50, 1200);
            SetWaitForTime(0.5);
        }
        line_bmp(80, 2500);
        SetWaitForTime(0.5);
        var0 = GetAICamData(1);
        if ( var0<110||var0>160 )
        {
            turn_angle(-50, 1200);
            SetWaitForTime(0.5);
            SetWaitForStraight(_M1_, _M2_, 80, 2000);
            SetWaitForStraight(_M1_, _M2_, -80, 2000);
            turn_angle(50, 1200);
            SetWaitForTime(0.5);
        }
        line_bmp(80, 10000);
        SetWaitForTime(0.5);
    }
    while(1);
}

