#ifndef _LIGHT01_
#define _LIGHT01_
#include "HardwareInfo.c"
#include <GetTraceV2I2C.h>
#include "getBit.c"
#include <SetWaitForTime.h>
#include <GetData.h>
#include <GetLightSensor.h>

extern u16 G1,G2,G3,G4,G5;
extern u16 tempCS;


void light01()
{
    // extern global var
    extern unsigned int S1;
    extern unsigned int S2;
    extern unsigned int S3;
    extern unsigned int S4;
    extern unsigned int S5;
    extern int mode;
    extern unsigned int S6;
    extern unsigned int S7;

    unsigned int PP1 = 0;
    unsigned int PP2 = 0;
    unsigned int PP3 = 0;
    unsigned int PP4 = 0;
    unsigned int PP5 = 0;
    unsigned char var0 = 0;
    long P6 = 0;
    var0 = GetTraceV2I2C(_P1_, 9);
    S1 = getBit(var0, 1);
    S2 = getBit(var0, 2);
    S3 = getBit(var0, 3);
    S4 = getBit(var0, 4);
    S5 = getBit(var0, 5);
    S6 = getBit(var0, 6);
    S7 = getBit(var0, 7);
    	
    	if(mode==1)
    	{
    	S1 = !S1;
        S2 =!S2;
        S3 =!S3 ;
        S4 = !S4;
        S5 = !S5;
        S6 = !S6;
        S7 = !S7;
        }
        
}
#endif

