#ifndef _DAYING_
#define _DAYING_
#include "HardwareInfo.c"
#include <GetAICamData.h>
#include <SetDisplayVar.h>

void daying()
{
    var0 = GetAICamData(1);
    var1 = GetAICamData(2);
    var2 = GetAICamData(3);
    var3 = GetAICamData(4);
    SetDisplayVar(1, var0, YELLOW, BLACK);
    SetDisplayVar(2, var1, YELLOW, BLACK);
    SetDisplayVar(3, var2, YELLOW, BLACK);
    SetDisplayVar(4, var3, YELLOW, BLACK);
}
#endif

