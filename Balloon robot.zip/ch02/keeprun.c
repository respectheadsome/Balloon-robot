#ifndef _KEEPRUN_
#define _KEEPRUN_
#include "HardwareInfo.c"
#include <SetMotor.h>
#include <GetMotorCode.h>
#include <SetWaitForTime.h>
#include <SetMotorCode.h>

void keeprun(int which, int speed)
{
    long var0 = 0;
    long var1 = 0;
    if ( which==1 )
    {
        while (1)
        {
            SetMotor(_M1_, speed);
            var0 = GetMotorCode(_M1_);
            SetWaitForTime(0.1);
            var1 = GetMotorCode(_M2_);
            if ( abs(var1-var0)<5 )
            {
                SetMotor(_M1_, 0);
                SetMotorCode(_M1_);
                break;
            }
        }
    }
    else
    {
        if ( which==2 )
        {
            while (1)
            {
                SetMotor(_M2_, speed);
                var0 = GetMotorCode(_M2_);
                SetWaitForTime(0.1);
                var1 = GetMotorCode(_M2_);
                if ( abs(var1-var0)<5 )
                {
                    SetMotor(_M2_, 0);
                    SetMotorCode(_M2_);
                    break;
                }
            }
        }
        else
        {
            if ( which==3 )
            {
                while (1)
                {
                    SetMotor(_M3_, speed);
                    var0 = GetMotorCode(_M3_);
                    SetWaitForTime(0.1);
                    var1 = GetMotorCode(_M3_);
                    if ( abs(var1-var0)<5 )
                    {
                        SetMotor(_M3_, 0);
                        SetMotorCode(_M3_);
                        break;
                    }
                }
            }
            else
            {
                if ( which==4 )
                {
                    while (1)
                    {
                        SetMotor(_M4_, speed);
                        var0 = GetMotorCode(_M4_);
                        SetWaitForTime(0.1);
                        var1 = GetMotorCode(_M4_);
                        if ( abs(var1-var0)<5 )
                        {
                            SetMotor(_M4_, 0);
                            SetMotorCode(_M4_);
                            break;
                        }
                    }
                }
            }
        }
    }
}
#endif

