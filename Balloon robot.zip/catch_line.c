#ifndef _CATCH_LINE_
#define _CATCH_LINE_
#include "HardwareInfo.c"
#include "line_time.c"
#include "goline.c"
#include <SetTraceV2BeepI2C.h>
#include "speed_control.c"

void catch_line(int sp, int light_w)
{
    // extern global var
    extern unsigned int S1;
    extern unsigned int S2;
    extern unsigned int S3;
    extern unsigned int S4;
    extern unsigned int S5;
    extern long light_ws;
    extern unsigned int S7;
    extern unsigned int S6;

    line_time(sp, 200);
    if ( light_w>=15 )
    {
        while (1)
        {
            goline(sp);
            if ( S1&&S7 )
            {
                break;
            }
        }
    }
    else
    {
        if ( light_w==1 )
        {
            while (1)
            {
                goline(sp);
                if ( S1 )
                {
                    break;
                }
            }
        }
        else
        {
            if ( light_w==7 )
            {
                while (1)
                {
                    goline(sp);
                    if ( S7 )
                    {
                        break;
                    }
                }
            }
            else
            {
                while (1)
                {
                    goline(sp);
                    if ( S1||S7 )
                    {
                        break;
                    }
                }
            }
        }
    }
    SetTraceV2BeepI2C(_P1_, 2);
    speed_control(0, 0);
}
#endif

